import { Controller, Post, Get, Body, Param, UseGuards } from '@nestjs/common';
import { CreateOrderDto } from '../../../core/dtos/create-order.dto';
import { OrdersService } from '../services/order.service';
import { AuthGuard } from '@nestjs/passport';
@Controller('api/orders')
@UseGuards(AuthGuard('jwt'))
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  @Post()
  async createOrder(@Body() createOrderDto: CreateOrderDto) {
    return await this.ordersService.createOrder(createOrderDto);
  }

  @Get(':orderId')
  async getOrder(@Param('orderId') orderId: string) {
    return await this.ordersService.getOrder(parseInt(orderId));
  }
}
