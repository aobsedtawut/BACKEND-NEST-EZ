import { Injectable, ConflictException } from '@nestjs/common';
import { CreateOrderDto } from '../../../core/dtos/create-order.dto';
import { IOrderRepository } from 'src/core/domain/repositories/order.repository';
import { IProductRepository } from 'src/core/domain/repositories/product.repository';
import { ICustomerRepository } from 'src/core/domain/repositories/customer.repository';
import { PrismaService } from 'src/infrastructure/prisma/services/prisma.service';

@Injectable()
export class OrdersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly orderRepository: IOrderRepository,
    private readonly productRepository: IProductRepository,
    private readonly customerRepository: ICustomerRepository,
  ) {}

  async createOrder(createOrderDto: CreateOrderDto) {
    return await this.prisma.$transaction(async () => {
      // 1. Check product availability
      const products = await this.productRepository.findManyByIds(
        createOrderDto.items.map((item) => item.productId),
      );

      // Validate stock availability
      for (const item of createOrderDto.items) {
        const product = products.find((p) => p.id === item.productId);
        const availableStock = await this.productRepository.getAvailableStock(
          item.productId,
        );

        if (!product || availableStock < item.quantity) {
          throw new ConflictException(
            `Insufficient stock for product ${item.productId}`,
          );
        }
      }

      // 2. Calculate total price
      const total = createOrderDto.items.reduce((acc, item) => {
        const product = products.find((p) => p.id === item.productId);
        return acc + product.price * item.quantity;
      }, 0);

      // 3. Check customer balance
      const customer = await this.customerRepository.findById(
        createOrderDto.customerId,
      );
      if (customer.balance < total) {
        throw new ConflictException('Insufficient balance');
      }

      // 4. Create order and update stock
      const order = await this.orderRepository.create({
        customerId: createOrderDto.customerId,
        status: 'PROCESSING',
        total,
        items: createOrderDto.items.map((item) => ({
          productId: item.productId,
          quantity: item.quantity,
          price: products.find((p) => p.id === item.productId).price,
        })),
      });

      // 5. Update stock status
      await this.productRepository.reserveStock(
        createOrderDto.items.map((item) => ({
          productId: item.productId,
          quantity: item.quantity,
        })),
      );

      // 6. Deduct customer balance
      await this.customerRepository.deductBalance(
        createOrderDto.customerId,
        total,
      );

      return {
        transactionId: order.id,
        status: 'PROCESSING',
      };
    });
  }

  async getOrder(orderId: number) {
    return await this.orderRepository.findById(orderId);
  }
}
