import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { OrdersService } from './module/orders/services/order.service';
import { PrismaService } from './infrastructure/prisma/services/prisma.service';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './infrastructure/prisma/prisma.module';
import { OrderModule } from './module/orders/order.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    PrismaModule,
    OrderModule,
  ],
  controllers: [AppController],
  providers: [AppService, OrdersService, PrismaService],
})
export class AppModule {}
