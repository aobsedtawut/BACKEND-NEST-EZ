import {
  Injectable,
  ConflictException,
  NotFoundException,
} from '@nestjs/common';
import { IProductRepository } from '../../core/domain/repositories/product.repository';
import { Product } from '../../core/domain/entities/product.entity';
import { Stock, StockStatus } from '../../core/domain/entities/stock.entity';
import { PrismaService } from '../prisma/services/prisma.service';
import { Prisma } from '@prisma/client';

@Injectable()
export class PrismaProductRepository implements IProductRepository {
  constructor(private prisma: PrismaService) {}

  private mapToProduct(prismaProduct: any): Product {
    return new Product({
      ...prismaProduct,
      stocks: prismaProduct.stocks?.map((stock) => new Stock(stock)),
    });
  }

  private async validateProductExists(id: number): Promise<void> {
    const exists = await this.prisma.product.count({ where: { id } });
    if (!exists) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }
  }

  async findById(id: number): Promise<Product> {
    const product = await this.prisma.product.findUnique({
      where: { id },
      include: {
        stocks: true,
      },
    });
    return product ? this.mapToProduct(product) : null;
  }

  async findManyByIds(ids: number[]): Promise<Product[]> {
    const products = await this.prisma.product.findMany({
      where: {
        id: { in: ids },
      },
      include: {
        stocks: true,
      },
    });
    return products.map((product) => this.mapToProduct(product));
  }

  async getAvailableStock(productId: number): Promise<number> {
    await this.validateProductExists(productId);

    return this.prisma.stock.count({
      where: {
        productId,
        status: StockStatus.IN_STOCK,
      },
    });
  }

  async reserveStock(
    items: Array<{ productId: number; quantity: number }>,
  ): Promise<void> {
    try {
      await this.prisma.$transaction(async (prisma) => {
        for (const item of items) {
          const availableStocks = await this.findAvailableStocks(
            prisma,
            item.productId,
            item.quantity,
          );

          await this.reserveStocks(prisma, availableStocks);
        }
      });
    } catch (error) {
      if (error instanceof ConflictException) {
        throw error;
      }
      throw new Error(`Failed to reserve stock: ${error.message}`);
    }
  }

  private async findAvailableStocks(
    prisma: Prisma.TransactionClient,
    productId: number,
    quantity: number,
  ): Promise<Stock[]> {
    const availableStocks = await prisma.stock.findMany({
      where: {
        productId,
        status: StockStatus.IN_STOCK,
      },
      take: quantity,
      orderBy: {
        createdAt: 'asc', // FIFO principle
      },
    });

    if (availableStocks.length < quantity) {
      throw new ConflictException(
        `Insufficient stock for product ${productId}. Required: ${quantity}, Available: ${availableStocks.length}`,
      );
    }

    return availableStocks.map(
      (stock) => new Stock({ ...stock, status: stock.status as StockStatus }),
    );
  }

  private async reserveStocks(
    prisma: Prisma.TransactionClient,
    stocks: Stock[],
  ): Promise<void> {
    const stockIds = stocks.map((stock) => stock.id);

    await prisma.stock.updateMany({
      where: {
        id: { in: stockIds },
      },
      data: {
        status: StockStatus.RESERVED,
      },
    });
  }

  async create(data: Partial<Product>): Promise<Product> {
    try {
      const product = await this.prisma.product.create({
        data: {
          name: data.name,
          description: data.description,
          price: data.price,
          denomination: data.denomination,
        },
        include: {
          stocks: true,
        },
      });
      return this.mapToProduct(product);
    } catch (error) {
      if (error.code === 'P2002') {
        throw new ConflictException('Product with this name already exists');
      }
      throw error;
    }
  }

  async update(id: number, data: Partial<Product>): Promise<Product> {
    await this.validateProductExists(id);

    try {
      const product = await this.prisma.product.update({
        where: { id },
        data: {
          name: data.name,
          description: data.description,
          price: data.price,
          denomination: data.denomination,
        },
        include: {
          stocks: true,
        },
      });
      return this.mapToProduct(product);
    } catch (error) {
      if (error.code === 'P2002') {
        throw new ConflictException('Product with this name already exists');
      }
      throw error;
    }
  }

  async delete(id: number): Promise<void> {
    await this.validateProductExists(id);

    await this.prisma.$transaction(async (prisma) => {
      await prisma.stock.deleteMany({
        where: { productId: id },
      });
      await prisma.product.delete({
        where: { id },
      });
    });
  }

  async releaseExpiredReservations(): Promise<void> {
    await this.prisma.stock.updateMany({
      where: {
        status: StockStatus.RESERVED,
      },
      data: {
        status: StockStatus.IN_STOCK,
      },
    });
  }

  async confirmReservation(stockIds: number[], orderId: number): Promise<void> {
    try {
      await this.prisma.stock.updateMany({
        where: {
          id: { in: stockIds },
          status: StockStatus.RESERVED,
        },
        data: {
          status: StockStatus.SOLD,
          orderId,
        },
      });
    } catch (error) {
      throw new Error(`Failed to confirm reservation: ${error.message}`);
    }
  }
}
