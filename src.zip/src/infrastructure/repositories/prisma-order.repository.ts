import { Injectable } from '@nestjs/common';
import { IOrderRepository } from '../../core/domain/repositories/order.repository';
import { Order, OrderItem } from '../../core/domain/entities/order.entity';
import { PrismaService } from '../prisma/services/prisma.service';
import { OrderStatus } from '@prisma/client';

@Injectable()
export class PrismaOrderRepository implements IOrderRepository {
  constructor(private prisma: PrismaService) {}

  private mapToOrder(prismaOrder: any): Order {
    // Map order items first
    const items =
      prismaOrder.items?.map(
        (item) =>
          new OrderItem({
            id: item.id,
            orderId: item.orderId,
            productId: item.productId,
            quantity: item.quantity,
            price: item.price,
            product: item.product,
          }),
      ) || [];

    // Create new Order instance with all properties including items
    return new Order({
      id: prismaOrder.id,
      customerId: prismaOrder.customerId,
      status: prismaOrder.status,
      total: prismaOrder.total,
      items: items,
      createdAt: prismaOrder.createdAt,
      updatedAt: prismaOrder.updatedAt,
      customer: prismaOrder.customer,
    });
  }

  async findById(id: number): Promise<Order> {
    const order = await this.prisma.order.findUnique({
      where: { id },
      include: {
        items: {
          include: {
            product: true,
          },
        },
      },
    });
    return order ? this.mapToOrder(order) : null;
  }

  async findMany(params: {
    skip?: number;
    take?: number;
    where?: any;
  }): Promise<Order[]> {
    const orders = await this.prisma.order.findMany({
      ...params,
      include: {
        items: {
          include: {
            product: true,
          },
        },
      },
    });
    return orders.map((order) => this.mapToOrder(order));
  }

  async create(data: {
    customerId: number;
    status: OrderStatus;
    total: number;
    items: Array<{
      productId: number;
      quantity: number;
      price: number;
    }>;
  }): Promise<Order> {
    const order = await this.prisma.order.create({
      data: {
        customerId: data.customerId,
        status: data.status,
        total: data.total,
        items: {
          create: data.items,
        },
      },
      include: {
        items: {
          include: {
            product: true,
          },
        },
      },
    });
    return this.mapToOrder(order);
  }

  async update(id: number, data: Partial<Order>): Promise<Order> {
    const order = await this.prisma.order.update({
      where: { id },
      data: {
        status: data.status,
        total: data.total,
        // Add other fields as needed
      },
      include: {
        items: {
          include: {
            product: true,
          },
        },
      },
    });
    return this.mapToOrder(order);
  }

  async delete(id: number): Promise<void> {
    await this.prisma.order.delete({
      where: { id },
    });
  }

  async findOrderWithItems(orderId: number): Promise<Order> {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: {
        items: {
          include: {
            product: true,
          },
        },
        stocks: true,
      },
    });
    return order ? this.mapToOrder(order) : null;
  }

  async updateStatus(orderId: number, status: OrderStatus): Promise<Order> {
    const order = await this.prisma.order.update({
      where: { id: orderId },
      data: { status },
      include: {
        items: {
          include: {
            product: true,
          },
        },
      },
    });
    return this.mapToOrder(order);
  }

  async findCustomerOrders(customerId: number): Promise<Order[]> {
    const orders = await this.prisma.order.findMany({
      where: { customerId },
      include: {
        items: {
          include: {
            product: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });
    return orders.map((order) => this.mapToOrder(order));
  }
}
