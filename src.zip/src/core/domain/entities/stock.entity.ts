import { Order } from './order.entity';
import { Product } from './product.entity';

export enum StockStatus {
  IN_STOCK = 'IN_STOCK',
  RESERVED = 'RESERVED',
  SOLD = 'SOLD',
}

export class Stock {
  id: number;
  productId: number;
  code: string;
  status: StockStatus;
  createdAt: Date;
  updatedAt: Date;
  product?: Product;
  order?: Order;
  orderId?: number;
  constructor(partial: Partial<Stock>) {
    Object.assign(this, partial);
  }

  isAvailable(): boolean {
    return this.status === StockStatus.IN_STOCK;
  }

  reserve(): void {
    if (!this.isAvailable()) {
      throw new Error('Stock is not available');
    }
    this.status = StockStatus.RESERVED;
  }

  sell(orderId: number): void {
    if (this.status !== StockStatus.RESERVED) {
      throw new Error('Stock must be reserved before selling');
    }
    this.status = StockStatus.SOLD;
    this.orderId = orderId;
  }
}
