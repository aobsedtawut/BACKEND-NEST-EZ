import { Stock } from '@prisma/client';
import { Customer } from './customer.entity';
import { Product } from './product.entity';

export enum OrderStatus {
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
}

export class OrderItem {
  id: number;
  orderId: number;
  productId: number;
  quantity: number;
  price: number;
  order?: Order;
  product?: Product;

  constructor(partial: Partial<OrderItem>) {
    Object.assign(this, partial);
  }

  getTotalPrice(): number {
    return this.quantity * this.price;
  }
}

export class Order {
  id: number;
  customerId: number;
  status: OrderStatus;
  total: number;
  createdAt: Date;
  updatedAt: Date;
  customer?: Customer;
  items: OrderItem[];
  stocks?: Stock[];

  constructor(partial: Partial<Order>) {
    Object.assign(this, partial);
    this.items = partial.items?.map((item) => new OrderItem(item)) || [];
  }

  calculateTotal(): number {
    return this.items.reduce((sum, item) => sum + item.getTotalPrice(), 0);
  }

  canComplete(): boolean {
    return this.status === OrderStatus.PROCESSING;
  }

  complete(): void {
    if (!this.canComplete()) {
      throw new Error('Order cannot be completed');
    }
    this.status = OrderStatus.COMPLETED;
  }

  addItem(item: OrderItem): void {
    this.items.push(item);
    this.total = this.calculateTotal();
  }

  removeItem(itemId: number): void {
    const index = this.items.findIndex((item) => item.id === itemId);
    if (index > -1) {
      this.items.splice(index, 1);
      this.total = this.calculateTotal();
    }
  }

  isProcessing(): boolean {
    return this.status === OrderStatus.PROCESSING;
  }

  isFailed(): boolean {
    return this.status === OrderStatus.FAILED;
  }

  isCompleted(): boolean {
    return this.status === OrderStatus.COMPLETED;
  }
}
