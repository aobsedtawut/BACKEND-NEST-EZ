export class Customer {
  id: number;
  email: string;
  balance: number;
  createdAt: Date;
  updatedAt: Date;

  constructor(partial: Partial<Customer>) {
    Object.assign(this, partial);
  }
}
