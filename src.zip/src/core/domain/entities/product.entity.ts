export class Product {
  id: number;
  name: string;
  description?: string;
  price: number;
  denomination: number;
  createdAt: Date;
  updatedAt: Date;

  constructor(partial: Partial<Product>) {
    Object.assign(this, partial);
  }

  hasAvailableStock(quantity: number): boolean {
    return quantity > 0;
  }
}
