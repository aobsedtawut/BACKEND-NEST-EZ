import { Order } from '../entities/order.entity';

export interface IOrderRepository {
  findById(id: number): Promise<Order>;
  findOrderWithItems(orderId: number): Promise<Order>;
  findCustomerOrders(customerId: number): Promise<Order[]>;
  create(data: {
    customerId: number;
    status: string;
    total: number;
    items: Array<{
      productId: number;
      quantity: number;
      price: number;
    }>;
  }): Promise<Order>;
  updateStatus(orderId: number, status: string): Promise<Order>;
  update(id: number, data: Partial<Order>): Promise<Order>;
  delete(id: number): Promise<void>;
}
