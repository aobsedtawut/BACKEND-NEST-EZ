import { Customer } from '../entities/customer.entity';

export interface ICustomerRepository {
  findById(id: number): Promise<Customer>;
  findByEmail(email: string): Promise<Customer>;
  getBalance(customerId: number): Promise<number>;
  deductBalance(customerId: number, amount: number): Promise<Customer>;
  addBalance(customerId: number, amount: number): Promise<Customer>;
  create(data: Partial<Customer>): Promise<Customer>;
  update(id: number, data: Partial<Customer>): Promise<Customer>;
}
