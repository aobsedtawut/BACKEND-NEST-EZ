import { Stock, StockStatus } from '../entities/stock.entity';

export interface IStockRepository {
  findById(id: number): Promise<Stock>;
  findByCode(code: string): Promise<Stock>;
  findByOrderId(orderId: number): Promise<Stock[]>;
  findAvailableByProductId(
    productId: number,
    quantity: number,
  ): Promise<Stock[]>;
  updateStatus(stockId: number, status: StockStatus): Promise<Stock>;
  bulkUpdateStatus(stockIds: number[], status: StockStatus): Promise<void>;
  assignToOrder(stockIds: number[], orderId: number): Promise<void>;
  create(data: Partial<Stock>): Promise<Stock>;
  createMany(data: Partial<Stock>[]): Promise<number>;
}
