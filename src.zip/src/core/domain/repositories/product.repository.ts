import { Product } from '../entities/product.entity';

export interface IProductRepository {
  findById(id: number): Promise<Product>;
  findManyByIds(ids: number[]): Promise<Product[]>;
  reserveStock(
    items: Array<{ productId: number; quantity: number }>,
  ): Promise<void>;
  getAvailableStock(productId: number): Promise<number>;
  create(data: Partial<Product>): Promise<Product>;
  update(id: number, data: Partial<Product>): Promise<Product>;
  delete(id: number): Promise<void>;
}
