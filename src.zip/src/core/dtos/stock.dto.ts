import { IsString } from 'class-validator';
import { StockStatus } from '../domain/entities/stock.entity';

export class CreateStockDto {
  @IsString()
  code: string;
}

export class StockResponseDto {
  id: number;
  productId: number;
  code: string;
  status: StockStatus;
  orderId?: number;
  createdAt: Date;
  updatedAt: Date;
}
