import { Stock } from '@prisma/client';
import { Product } from '@prisma/client';
import { OrderResponseDto } from '../create-order.dto';
import { ProductResponseDto } from '../product.dto';
import { StockResponseDto } from '../stock.dto';
import { StockStatus } from 'src/core/domain/entities/stock.entity';
import { Customer } from 'src/core/domain/entities/customer.entity';
import { CustomerResponseDto } from '../customer.dto';
import { Order } from 'src/core/domain/entities/order.entity';

export class DtoMapper {
  static toOrderResponse(order: Order): OrderResponseDto {
    return {
      id: order.id,
      status: order.status,
      total: order.total,
      items: order.items.map((item) => ({
        productId: item.productId,
        quantity: item.quantity,
        price: item.price,
      })),
      createdAt: order.createdAt,
    };
  }

  static toProductResponse(
    product: Product,
    stockCount: number,
  ): ProductResponseDto {
    return {
      id: product.id,
      name: product.name,
      description: product.description,
      price: product.price.toNumber(),
      denomination: product.denomination.toNumber(),
      stockCount,
      createdAt: product.createdAt,
      updatedAt: product.updatedAt,
    };
  }

  static toStockResponse(stock: Stock): StockResponseDto {
    return {
      id: stock.id,
      productId: stock.productId,
      code: stock.code,
      status: stock.status as StockStatus,
      orderId: stock.orderId,
      createdAt: stock.createdAt,
      updatedAt: stock.updatedAt,
    };
  }

  static toCustomerResponse(customer: Customer): CustomerResponseDto {
    return {
      id: customer.id,
      email: customer.email,
      balance: customer.balance,
      createdAt: customer.createdAt,
      updatedAt: customer.updatedAt,
    };
  }
}
