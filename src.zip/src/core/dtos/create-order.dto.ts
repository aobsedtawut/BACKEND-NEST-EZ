import {
  IsInt,
  IsPositive,
  ValidateNested,
  ArrayMinSize,
  IsArray,
} from 'class-validator';
import { Type } from 'class-transformer';

export class OrderItemDto {
  @IsInt()
  @IsPositive()
  productId: number;

  @IsInt()
  @IsPositive()
  quantity: number;
}

export class CreateOrderDto {
  @IsInt()
  @IsPositive()
  customerId: number;

  @IsArray()
  @ValidateNested({ each: true })
  @ArrayMinSize(1)
  @Type(() => OrderItemDto)
  items: OrderItemDto[];
}

export class OrderResponseDto {
  id: number;
  status: string;
  total: number;
  items: Array<{
    productId: number;
    quantity: number;
    price: number;
  }>;
  createdAt: Date;
}
